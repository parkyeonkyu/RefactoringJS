

export function doUpload(callback1) {
    console.log('doUpload');
    callback1();
}